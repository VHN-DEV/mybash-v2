#!/bin/bash

# Load config
CONFIG_FILE=${1:-"./config/project_config.conf"}
if [ ! -f "$CONFIG_FILE" ]; then
    echo -e "\033[1;31mError: Configuration file $CONFIG_FILE not found! Exiting...\033[0;39m"
    exit 1
fi
source "$CONFIG_FILE"

# Định nghĩa màu sắc
NORMAL="\033[0;39m"
BLUE="\033[1;34m"
ORANGE="\033[1;33m"
RED="\033[1;31m"

# Kiểm tra các tham số bắt buộc
if [ -z "$DOMAIN_NAME" ] || [ -z "$PHP_VERSION" ] || [ -z "$ROOT_DIR" ]; then
    echo -e "${RED}Missing configuration! Please check $CONFIG_FILE${NORMAL}"
    exit 1
fi

if [ -z "$GIT" ]; then
    echo -e "${RED}No Git repository specified in the configuration file.${NORMAL}"
    exit 1
fi

# Đường dẫn dự án
PROJECT_PATH="$ROOT_DIR"

# Kiểm tra nếu thư mục đã tồn tại
if [ -d "$PROJECT_PATH" ]; then
    echo -e "${ORANGE}Project directory $PROJECT_PATH already exists.${NORMAL}"
    read -p "Do you want to remove it and create a new one? [y/N]: " choice
    case "$choice" in
        y|Y)
            echo -e "${BLUE}Removing existing project directory...${NORMAL}"
            sudo rm -rf "$PROJECT_PATH"
            if [ $? -eq 0 ]; then
                echo -e "${BLUE}Removed existing project directory successfully!${NORMAL}"
            else
                echo -e "${RED}Failed to remove existing project directory! Exiting...${NORMAL}"
                exit 1
            fi
            ;;
        *)
            echo -e "${RED}Operation aborted by user.${NORMAL}"
            exit 1
            ;;
    esac
fi

# Tạo thư mục dự án
echo -e "${BLUE}Creating project folder...${NORMAL}"
if sudo mkdir -p "$PROJECT_PATH"; then
    sudo chmod -R 777 "$PROJECT_PATH"
    echo -e "${BLUE}Project folder created: $PROJECT_PATH${NORMAL}"
else
    echo -e "${RED}Failed to create project folder! Exiting...${NORMAL}"
    exit 1
fi


# Git clone dự án
echo -e "${BLUE}Cloning Git repository...${NORMAL}"
if git clone "$GIT" "$PROJECT_PATH"; then
    echo -e "${BLUE}Repository cloned successfully!${NORMAL}"

    # Thêm thư mục vào danh sách safe.directory
    echo -e "${BLUE}Adding project directory to Git safe.directory...${NORMAL}"
    git config --global --add safe.directory "$PROJECT_PATH"
    if [ $? -eq 0 ]; then
        echo -e "${BLUE}Added $PROJECT_PATH to Git safe.directory successfully!${NORMAL}"
    else
        echo -e "${RED}Failed to add $PROJECT_PATH to Git safe.directory!${NORMAL}"
        exit 1
    fi
else
    echo -e "${RED}Failed to clone repository! Exiting...${NORMAL}"
    exit 1
fi

# Chuyển sang nhánh git được chỉ định
echo -e "${BLUE}Checking out branch: $GIT_BRANCH...${NORMAL}"
cd "$PROJECT_PATH" || exit 1
if git checkout "$GIT_BRANCH"; then
    echo -e "${BLUE}Checked out to branch $GIT_BRANCH successfully!${NORMAL}"
else
    echo -e "${RED}Failed to checkout branch $GIT_BRANCH! Exiting...${NORMAL}"
    exit 1
fi

# Chạy script bổ sung nếu có
if [ -n "$SCRIPT" ]; then
    echo -e "${BLUE}Running post-clone script...${NORMAL}"
    eval "$SCRIPT"
    if [ $? -eq 0 ]; then
        echo -e "${BLUE}Script executed successfully!${NORMAL}"
    else
        echo -e "${RED}Failed to execute the script: $SCRIPT!${NORMAL}"
        exit 1
    fi
fi

# Tạo file cấu hình Nginx
NGINX_CONF="/etc/nginx/sites-available/$DOMAIN_NAME"
echo -e "${BLUE}Creating Nginx configuration...${NORMAL}"
cat <<EOL > $NGINX_CONF
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN_NAME;
    root $PROJECT_PATH/public;
    index index.php index.html;
    ssl_certificate     /etc/ssl/certs/ssl-cert-snakeoil.pem;
    ssl_certificate_key /etc/ssl/private/ssl-cert-snakeoil.key;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php$PHP_VERSION-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
    }
    
    location ^~ /.well-known/pki-validation/ {
        allow all;
        default_type "text/plain";
    }

    location ~ /\. {
        deny all;
    }
}
EOL

if [ $? -eq 0 ]; then
    echo -e "${BLUE}Nginx configuration created: $NGINX_CONF${NORMAL}"
else
    echo -e "${RED}Failed to create Nginx configuration! Exiting...${NORMAL}"
    exit 1
fi

# Kích hoạt cấu hình Nginx
echo -e "${BLUE}Activating Nginx site...${NORMAL}"
if sudo ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/ && sudo systemctl restart nginx; then
    echo -e "${BLUE}Nginx restarted successfully!${NORMAL}"
else
    echo -e "${RED}Failed to restart Nginx. Check configuration and try again.${NORMAL}"
    exit 1
fi

# Thêm domain vào /etc/hosts
if ! grep -q "$DOMAIN_NAME" /etc/hosts; then
    echo "127.0.0.1       $DOMAIN_NAME" | sudo tee -a /etc/hosts > /dev/null
    echo -e "${BLUE}Added $DOMAIN_NAME to /etc/hosts${NORMAL}"
else
    echo -e "${ORANGE}$DOMAIN_NAME already exists in /etc/hosts${NORMAL}"
fi

# Hoàn thành
echo -e "${ORANGE}Project created successfully!${NORMAL}"
echo -e "${ORANGE}Site: https://$DOMAIN_NAME${NORMAL}"
echo -e "${ORANGE}Folder: $PROJECT_PATH${NORMAL}"
