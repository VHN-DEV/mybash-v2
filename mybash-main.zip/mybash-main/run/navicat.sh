echo "-> Start navicat"

chmod +x "$HOME"/navicat17-premium-lite-en-x86_64.AppImage
"$HOME"/navicat17-premium-lite-en-x86_64.AppImage -d
