#! bash bin
sudo apt-get update
sudo apt install redis-server