#! bin/bash

sudo bash data/clear-log.sh exec
