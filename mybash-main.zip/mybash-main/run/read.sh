FILES=`ls *.sh`
for EACH_FILE in $FILES
do
   echo $EACH_FILE
done
