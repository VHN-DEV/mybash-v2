#! bin/bash

sudo bash data/clear-tmp.sh exec