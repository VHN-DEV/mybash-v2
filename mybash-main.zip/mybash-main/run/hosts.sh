!# bin/bash

echo "--> Read files hosts"
nano /etc/hosts
