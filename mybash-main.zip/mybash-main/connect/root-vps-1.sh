#! bash bin
sshpass -p Coffee@2025! ssh admin_user@15.235.187.19 -p 9989
