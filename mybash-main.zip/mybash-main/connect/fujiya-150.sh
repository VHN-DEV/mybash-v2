#!/bin/bash
sshpass -p T6od9DQ7eAZRfHl ssh fujiya@192.168.10.150 -p 1506
