#!/bin/bash
sshpass -p N5wJkg2LhxxOwXDm0Yas ssh root@69.57.160.194 -p 22
