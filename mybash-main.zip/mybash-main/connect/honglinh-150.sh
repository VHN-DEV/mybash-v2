#!/bin/bash
sshpass -p rnJYPEe7yOL83CkY2OJ2  ssh honglinh@192.168.10.150 -p 1506
