#!/bin/bash
sshpass -p pAP3cdV2t ssh pull@192.168.10.150 -p 1506
