#!/bin/bash
sshpass -p rnnSAoUb ssh kiamotors@192.168.10.150 -p 1506
