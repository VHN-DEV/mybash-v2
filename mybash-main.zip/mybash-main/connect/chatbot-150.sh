#!/bin/bash
sshpass -p JHrwrkYpPU ssh chatbot@192.168.10.150 -p 1506
