#!/bin/bash
sshpass -p wc8efFOr0 ssh maxwell@192.168.10.150 -p 1506
