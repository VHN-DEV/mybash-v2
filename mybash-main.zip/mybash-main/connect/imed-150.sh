#!/bin/bash
ssh imed@192.168.10.150 -p 1506
