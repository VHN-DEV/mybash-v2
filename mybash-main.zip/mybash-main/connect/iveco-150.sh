#!/bin/bash
sshpass -p ouLgcHf4Ra ssh iveco@192.168.10.150 -p 1506
