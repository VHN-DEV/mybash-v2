#!/bin/bash
sshpass -p DI06T1ER ssh lagoona@192.168.10.150 -p 1506
