#!/bin/bash
sshpass -p 7ecQHKNI8 ssh taibus@192.168.10.150 -p 1506
