#!/bin/bash
sshpass -p QqkG3uLZ4MNWRMc ssh samsung@192.168.10.169 -p 1506
