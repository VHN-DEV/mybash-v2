#!/bin/bash
sshpass -p FJbQ1DNEIN ssh dev@192.168.10.150 -p 1506
