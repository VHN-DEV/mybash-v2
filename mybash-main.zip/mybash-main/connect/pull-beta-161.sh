#!/bin/bash
sshpass -p gMTJCuU3 ssh pull@192.168.10.161 -p 1506
