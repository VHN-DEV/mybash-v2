#!/bin/bash
sshpass -p OT1m4ruwgoZFbiRUBy4w ssh root@162.254.36.136 -p 22
