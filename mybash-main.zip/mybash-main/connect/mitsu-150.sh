#!/bin/bash
sshpass -p YCl9Kj5VWE ssh preprod@192.168.10.150 -p 1506
