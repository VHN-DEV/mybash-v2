#!/bin/bash
sshpass -p y6rNmNfjTN62r1ECoZDP ssh root@66.29.144.243 -p 22
