#!/bin/bash
sshpass -p BsGHP0gJ8NhIpjS ssh webdemo@192.168.10.161 -p 1506
