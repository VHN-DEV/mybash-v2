#!/bin/bash
sshpass -p ZFn4nX6WH1eme5o ssh haili@192.168.10.150 -p 1506
