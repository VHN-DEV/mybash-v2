#!/bin/bash
sshpass -p N1JH1GsRpcU9NBo ssh dev@192.168.10.163
