#!/bin/bash

# DEFAULT VARIABLES
PHP_VERSION="8.2"
APP_TYPE="laravel"
ROOT_DIR="/var/www"
GIT=""
GIT_BRANCH="develop"
DOMAIN_NAME=""
CONFIG_DIR="./config" # Thư mục lưu file cấu hình

# Tạo thư mục config nếu chưa tồn tại
mkdir -p $CONFIG_DIR

# FUNCTION: Tạo file cấu hình
create_project_config() {
  CONFIG_FILE="$CONFIG_DIR/$DOMAIN_NAME.conf"

  echo "Tạo file cấu hình tại: $CONFIG_FILE"
  cat <<EOL >$CONFIG_FILE
PHP_VERSION="$PHP_VERSION"
APP_TYPE="$APP_TYPE"
ROOT_DIR="$ROOT_DIR/$DOMAIN_NAME"
GIT="$GIT"
GIT_BRANCH="$GIT_BRANCH"
SCRIPT=""
DOMAIN_NAME="$DOMAIN_NAME"
EOL
  echo "Đã tạo file cấu hình thành công!"
  echo "$CONFIG_FILE"
}

# Menu chính
echo "Chọn chức năng:"
echo "[1] Tạo mới dự án"
echo "[2] Danh sách dự án"
echo "[3] Tạo lại dự án từ config"
read -p "Nhập lựa chọn của bạn: " FUNCTION_CHOICE

case $FUNCTION_CHOICE in
1)
  echo "Bạn đã chọn: Tạo mới dự án"

  read -p "Nhập phiên bản PHP (mặc định: $PHP_VERSION): " INPUT_PHP_VERSION
  PHP_VERSION=${INPUT_PHP_VERSION:-$PHP_VERSION}

  read -p "Nhập nhánh Git (mặc định: $GIT_BRANCH): " INPUT_GIT_BRANCH
  GIT_BRANCH=${INPUT_GIT_BRANCH:-$GIT_BRANCH}

  read -p "Nhập tên miền: " DOMAIN_NAME

  read -p "Nhập đường dẫn Git repo: " GIT

  echo "Đang tạo dự án với thông tin:"
  echo "PHP Version: $PHP_VERSION"
  echo "Git Branch: $GIT_BRANCH"
  echo "Domain Name: $DOMAIN_NAME"
  echo "Git Repo: $GIT"

  # Tạo file cấu hình
  create_project_config

  # Hỏi người dùng xác nhận khởi tạo
  read -p "Bạn có muốn khởi tạo dự án với các option trên? [y/N]: " CONFIRM
  if [[ "$CONFIRM" =~ ^[yY]$ ]]; then
    bash nginx/init-nginx.sh "$CONFIG_FILE"
  else
    echo "Khởi tạo dự án đã bị hủy."
  fi
  ;;
2)
  echo "Bạn đã chọn: Danh sách dự án"
  # Kiểm tra xem thư mục config có file nào không
  if [ -z "$(ls -A $CONFIG_DIR)" ]; then
    echo "Thư mục config hiện không có file nào."
  else
    echo "Danh sách file cấu hình trong thư mục config:"
    ls -1 $CONFIG_DIR
  fi
  ;;
3)
  echo "Bạn đã chọn: Tạo lại dự án từ config"

  # Hỏi người dùng nhập tên config muốn chạy
  read -p "Nhập tên config muốn chạy (ví dụ: khaizinam.test.conf): " PATHNAME

  # Kiểm tra file cấu hình có tồn tại không
  CONFIG_FILE="./config/$PATHNAME"
  if [ -f "$CONFIG_FILE" ]; then
    # Chạy script init-nginx.sh với file cấu hình
    bash nginx/init-nginx.sh "$CONFIG_FILE"
  else
    echo "File cấu hình $PATHNAME không tồn tại."
  fi
  ;;
*)
  echo "Lựa chọn không hợp lệ. Vui lòng thử lại."
  ;;
esac
