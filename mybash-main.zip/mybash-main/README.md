# mybash

https://drive.google.com/drive/u/0/folders/1ttZxXQu1PKx8SYfLdSPECAKEMtB8XKqm

run: bash app.sh
